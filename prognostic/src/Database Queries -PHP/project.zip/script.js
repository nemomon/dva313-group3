

function getAllPersons()
{
      jQuery.ajax({ method: "POST",   
                 url: "getAllPersons.php",   
				 dataType: "json",
                 success : function(data)
                 {
				
					
			for(var i = 0; i<data.length; i++){
		    $("#showTable").append("<tr><td>"+data[i]["Id"]+"</td><td>"+data[i]["Name"]+"</td><td>"+data[i]["Salary"]+"</td><td>"+data[i]["SocialFactor"]+"</td><td>"+data[i]["IncrementFactor"]+"</td></tr>");
		
}
                 }
        });
		
		
}

function getAllProject()
{
      jQuery.ajax({ method: "POST",   
                 url: "getAllProject.php",   
				 dataType: "json",
                 success : function(data)
                 {
				
			
		for(var i = 0; i<data.length; i++){
		    $("#showTable").append("<tr><td>"+data[i]["Id"]+"</td><td>"+data[i]["Name"]+"</td><td>"+data[i]["EndDate"]+"</td><td>"+data[i]["ExternalSalary"]+"</td><td>"+data[i]["ExternalOverhead"]+"</td><td>"+data[i]["ExternalOtherCost"]+"</td><td>"+data[i]["InternalSalary"]+"</td><td>"+data[i]["InternalOverhead"]+"</td><td>"+data[i]["InternalOtherCost"]+"</td><td>"+data[i]["OverheadConstant"]+"</td><td>"+data[i]["Stl"]+"</td></tr>");
		
}
                 }
        });
		
		
}


function getAllAllocation()
{
      jQuery.ajax({ method: "POST",   
                 url: "getAllAllocation.php",   
				 dataType: "json",
                 success : function(data)
                 {
				
				
		for(var i = 0; i<data.length; i++){
		    $("#showTable").append("<tr><td>"+data[i]["Id"]+"</td><td>"+data[i]["personName"]+"</td><td>"+data[i]["projectName"]+"</td><td>"+data[i]["Percentage"]+"</td><td>"+data[i]["StartDate"]+"</td><td>"+data[i]["EndDate"]+"</td></tr>");
		
}
                 }
        });		
}


function getAllEndbalance()
{
      jQuery.ajax({ method: "POST",   
                 url: "getAllEndbalance.php",   
				 dataType: "json",
                 success : function(data)
                 {
				
					
		for(var i = 0; i<data.length; i++){
		    $("#showTable").append("<tr><td>"+data[i]["Id"]+"</td><td>"+data[i]["Name"]+"</td><td>"+data[i]["ExternalSalary"]+"</td><td>"+data[i]["InternalSalary"]+"</td><td>"+data[i]["ExternalOverhead"]+"</td><td>"+data[i]["InternalOverhead"]+"</td><td>"+data[i]["ExternalOtherCost"]+"</td><td>"+data[i]["InternalOtherCost"]+"</td></tr>");
		
}
                 }
        });		
}


function getAllRemaining()
{
      jQuery.ajax({ method: "POST",   
                 url: "getAllRemaining.php",   
				 dataType: "json",
                 success : function(data)
                 {
				
				
		for(var i = 0; i<data.length; i++){
		    $("#showTable").append("<tr><td>"+data[i]["Id"]+"</td><td>"+data[i]["Name"]+"</td><td>"+data[i]["SpendingDate"]+"</td><td>"+data[i]["ExternalSalary"]+"</td><td>"+data[i]["ExternalOverhead"]+"</td><td>"+data[i]["ExternalOtherCost"]+"</td><td>"+data[i]["InternalSalary"]+"</td><td>"+data[i]["InternalOverhead"]+"</td><td>"+data[i]["InternalOtherCost"]+"</td></tr>");
		
}
                 }
        });		
}

function getAllSpending()
{
      jQuery.ajax({ method: "POST",   
                 url: "getAllSpending.php",   
				 dataType: "json",
                 success : function(data)
                 {
				
				
		for(var i = 0; i<data.length; i++){
		    $("#showTable").append("<tr><td>"+data[i]["Name"]+"</td><td>"+data[i]["SpendingDate"]+"</td><td>"+data[i]["SpendingExternalSalary"]+"</td><td>"+data[i]["SpendingExternalOverhead"]+"</td><td>"+data[i]["SpendingExternalOtherCost"]+"</td><td>"+data[i]["SpendingInternalSalary"]+"</td><td>"+data[i]["SpendingInternalOverhead"]+"</td><td>"+data[i]["InternalOtherCost"]+"</td></tr>");
		
}
                 }
        });		
}


// call functions
//getAllPersons();
//getAllProject();
//getAllAllocation();
//getAllEndbalance();
//getAllRemaining();
getAllSpending();