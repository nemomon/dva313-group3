class project {

  constructor() {
 
  }
   
   getAllProject() {
   var r = JSON.parse( $.ajax({
    type: 'POST',
    url: 'getAllProject.php',
    async: false,
    dataType: 'json',
    async: false,
    done: function(response) {
        return response;
    }
	
}).responseText);
   
   return r;
  }
  
  
 deleteProject(Id){
   var r = $.ajax({
    type: 'POST',
    url: 'deleteProject.php',
	data: {Id: Id},
    async: false,
    done: function(response) {
        return response;
    }
}).responseText;
   return r;
  }


 insertProject(Name, EndDate, Stl, ExternalSalary, ExternalOverhead, ExternalOtherCost, InternalSalary, InternalOverhead, InternalOtherCost, SpendingExternalSalary, 
 SpendingExternalOverhead, SpendingExternalOtherCost, SpendingInternalSalary, SpendingInternalOverhead, SpendingInternalOtherCost, SpendingDate, OverheadConstant){
   var r = $.ajax({
    type: 'POST',
    url: 'insertProject.php',
	data: {Name: Name, EndDate: EndDate, Stl: Stl, ExternalSalary: ExternalSalary, ExternalOverhead: ExternalOverhead, ExternalOtherCost: ExternalOtherCost, 
	InternalSalary: InternalSalary, InternalOverhead: InternalOverhead, InternalOtherCost: InternalOtherCost, SpendingExternalSalary: SpendingExternalSalary, 
	SpendingExternalOverhead: SpendingExternalOverhead, SpendingExternalOtherCost: SpendingExternalOtherCost, 
	SpendingInternalSalary: SpendingInternalSalary, SpendingInternalOverhead: SpendingInternalOverhead, SpendingInternalOtherCost: SpendingInternalOtherCost, SpendingDate: SpendingDate, OverheadConstant: OverheadConstant},
    async: false,
    done: function(response) {
        return response;
    }
}).responseText;
   return r;
  }
  
  
  
  updateProject(Id, EndDate, Stl, ExternalSalary, ExternalOverhead, ExternalOtherCost, InternalSalary, InternalOverhead, InternalOtherCost, SpendingExternalSalary, 
 SpendingExternalOverhead, SpendingExternalOtherCost, SpendingInternalSalary, SpendingInternalOverhead, SpendingInternalOtherCost, SpendingDate, OverheadConstant){
	var r = $.ajax({ 
    type: 'POST',
    url: 'updateProject.php',
    data: {Id: Id, Name: Name, EndDate: EndDate, Stl: Stl, ExternalSalary: ExternalSalary, ExternalOverhead: ExternalOverhead, ExternalOtherCost: ExternalOtherCost, 
	InternalSalary: InternalSalary, InternalOverhead: InternalOverhead, InternalOtherCost: InternalOtherCost, SpendingExternalSalary: SpendingExternalSalary, 
	SpendingExternalOverhead: SpendingExternalOverhead, SpendingExternalOtherCost: SpendingExternalOtherCost, 
	SpendingInternalSalary: SpendingInternalSalary, SpendingInternalOverhead: SpendingInternalOverhead, SpendingInternalOtherCost: SpendingInternalOtherCost, SpendingDate: SpendingDate, OverheadConstant: OverheadConstant},
    async: false,
    done: function(response){
        return response ;    
    }
}).responseText;
return r;
}
  
}