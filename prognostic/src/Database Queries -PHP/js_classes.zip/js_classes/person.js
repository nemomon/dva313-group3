
class person {

  constructor() {
 
  }
   
   getAllPersons() {
   var r = JSON.parse( $.ajax({
    type: 'POST',
    url: 'getAllPersons.php',
    async: false,
    dataType: 'json',
    async: false,
    done: function(response) {
        return response;
    }
	
}).responseText);
   
   return r;
  }
  
  
 deletePerson(Id){
   var r = $.ajax({
    type: 'POST',
    url: 'deletePerson.php',
	data: {Id: Id},
    async: false,
    done: function(response) {
        return response;
    }
}).responseText;
   return r;
  }


 insertPerson(Name, Salary, SocialFactor, IncrementFactor){
   var r = $.ajax({
    type: 'POST',
    url: 'insertPerson.php',
	data: {Name: Name, Salary: Salary, SocialFactor: SocialFactor, IncrementFactor: IncrementFactor},
    async: false,
    done: function(response) {
        return response;
    }
}).responseText;
   return r;
  }
  
  
  
  updatePerson(Id, Name, Salary, SocialFactor, IncrementFactor){
	var r = $.ajax({ 
    type: 'POST',
    url: 'updatePerson.php',
    data: {Id: Id, Name: Name, Salary: Salary, SocialFactor: SocialFactor, IncrementFactor: IncrementFactor},
    async: false,
    done: function(response){
        return response ;    
    }
}).responseText;
return r;
}
 