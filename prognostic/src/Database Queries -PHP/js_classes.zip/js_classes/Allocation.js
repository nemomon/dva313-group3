
class Allocation {

  constructor() {
 
  }
   
   getAllAllocation() {
   var r = JSON.parse( $.ajax({
    type: 'POST',
    url: 'getAllAllocation.php',
    async: false,
    dataType: 'json',
    async: false,
    done: function(response) {
        return response;
    }
	
}).responseText);
   
   return r;
  }
  
  
 deleteAllocation(Id){
   var r = $.ajax({
    type: 'POST',
    url: 'deleteAllocation.php',
	data: {Id: Id},
    async: false,
    done: function(response) {
        return response;
    }
}).responseText;
   return r;
  }


 insertAllocation(personId, projectId, Percentage, StartDate, EndDate){
   var r = $.ajax({
    type: 'POST',
    url: 'insertAllocation.php',
	data: {personId: personId, projectId: projectId, Percentage: Percentage, StartDate: StartDate, EndDate: Enddate},
    async: false,
    done: function(response) {
        return response;
    }
}).responseText;
   return r;
  }
  
  
  
  updateAllocation(Id, Percentage, StartDate, EndDate){
	var r = $.ajax({ 
    type: 'POST',
    url: 'updateAllocation.php',
    data: {Id: Id, Percentage: Percentage, StartDate: StartDate, EndDate: EndDate},
    async: false,
    done: function(response){
        return response ;    
    }
}).responseText;
return r;
}
 