
class EndBalance {

  constructor() {
 
  }
   
   getAllEndBalance() {
   var r = JSON.parse( $.ajax({
    type: 'POST',
    url: 'getAllEndbalance.php',
    async: false,
    dataType: 'json',
    async: false,
    done: function(response) {
        return response;
    }
	
}).responseText);
   
   return r;
  }
  
   