
class Spending {

  constructor() {
 
  }
   
   getAllSpending() {
   var r = JSON.parse( $.ajax({
    type: 'POST',
    url: 'getAllSpending.php',
    async: false,
    dataType: 'json',
    async: false,
    done: function(response) {
        return response;
    }
	
}).responseText);
   
   return r;
  }
  
   